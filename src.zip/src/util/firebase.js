
import {initializeApp} from 'firebase/app';
import {getFirestore} from 'firebase/firestore';




const firebaseConfig = {

    apiKey: "AIzaSyDw1edfMkAaK1nxma3OLsvof8AwhCLLhdE",
  
    authDomain: "college-info-ff01e.firebaseapp.com",
  
    projectId: "college-info-ff01e",
  
    storageBucket: "college-info-ff01e.appspot.com",
  
    messagingSenderId: "88446485859",
  
    appId: "1:88446485859:web:165273e50d4de78e283f56",
  
    measurementId: "G-FWYCSPFLTZ"
  
  };
  
  
  // Initialize Firebase
  
  const app = initializeApp(firebaseConfig)
  const db=getFirestore(app)
export {db}
  
  
 

