import React from 'react';
import './college.css';
function College(props){
    return(
                <div>
                    <div className="d-flex flex-row bd-highlight mb-3 border border-dark border border-5 rounded-3" id='abc'>
                        <div className="p-2 bd-highlight">
                            <h1>{props.collegeObj.Name}</h1>
                            <img src={props.collegeObj.Picture} className='' />
                        </div>
                        <div className="p-2 bd-highlight" id='l1'>
                            <p>College Name:{props.collegeObj.Name}</p>
                            <br></br>
                            <p>Fee Per Annum:{props.collegeObj.Fee}</p>
                            <br></br>
                            <p>NIRF:{props.collegeObj.NIRF_rank}</p>
                            <br></br>
                            <p>Infrastructures:{props.collegeObj.Infrastructures}</p>

                        </div>
                        <div className="p-2 bd-highlight" id='l1'>
                            <p>Intakes:{props.collegeObj.Intake}</p>
                            <br></br>
                            <p>Courses:{props.collegeObj.Courses}</p>
                            <br></br>
                            <p>Highest package:{props.collegeObj.Highest_package}</p>
                            <br></br>
                            <button id='link' className='btn btn-dark'><a target="_blank" id='link' href={props.collegeObj.Link}>Further Details</a></button>
                            
                        </div>
                        
                    </div>
                   
                </div>


    )
}

export default College