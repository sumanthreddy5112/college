import React, { useEffect, useState } from 'react';
import College from './College'
import {collegeData} from '../data'
import './coll.css'
import {db} from '../util/firebase'
import { collection,getDocs } from 'firebase/firestore'; 
function Home(){
  let [college,setCollege]=useState('');
  let [value,setValue]=useState({});
  const changeCollege = (event)=>{
    setCollege(event.target.value);
  };
  const transferValue = (event) => {
    event.preventDefault();
    setValue({college});
    console.log(value);
}

  

    return(
        <div>
           <div id='head'>
           <form id='srh' className="d-flex w-50">
            <input className="form-control me-2" type="text" value={college} onChange={changeCollege} placeholder="Search" id='s'></input>
            <button className="btn btn-dark" onClick={transferValue} type="submit">Search</button>
    </form>
           </div>
           <div>
           {
                    collegeData.map((collegeObj, index) =>
                        value.college === collegeObj.Name && <College key={index} collegeObj={collegeObj}></College>)
                }

           </div>
      <div>
        {
          collegeData.map((collegeObj,index)=><College key={index} collegeObj={collegeObj}></College>)
        }
      </div>
      </div>
    )
    

}
export default Home