import { collection } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import {addDoc,getDocs} from 'firebase/firestore';
import {db} from '../util/firebase';
import { async } from '@firebase/util';
function Query(){
  const [email,setEmail]=useState("");
  const [desc,setDesc]=useState("");
  const handleSubmit =async(e)=>{
    e.preventDefault()
    try{
      await addDoc(collection(db,'Queries'),{
        email:email,
        description:desc
      })
      
    }catch(err){
      alert(err)
    }
  }
  
  
    return(
     

        <div className='container w-50'>
            <form className='mx-auto w-50 mt-5 p-3 bg-light rounded border-success shadow-lg' id='register-form' >
                <p className='display-6 text-center text-secondary'>Ask Us</p>
  <div className="row mb-3">
    <div className="col-sm-10">
      <input className="form-control" onChange={(event)=>{setEmail(event.target.value);}} placeholder='Email'/>
    </div> 
  </div>
  <div className="row mb-3">
      <div className="col-sm-10">
      <textarea className="form-control" onChange={(event)=>{setDesc(event.target.value);}} placeholder='Description'/>
    </div>
  </div>
  <button type="submit" className="btn btn-primary" onClick={handleSubmit}>Submit</button>
</form>
        </div>
    )
}
export default Query;