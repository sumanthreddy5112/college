import React from 'react';
import './college.css'
function Compcollege(props){
    return(
        <div>
            <div class="d-flex flex-column bd-highlight mb-3" id='def'>
                <div class="p-2 bd-highlight">College Name:{props.collegeObj.Name}</div>
                <div class="p-2 bd-highlight">Fee:{props.collegeObj.Fee}</div>
                <div class="p-2 bd-highlight">Courses:{props.collegeObj.Courses}</div>
                <div class="p-2 bd-highlight">NIRF Ranking:{props.collegeObj.NIRF_rank}</div>
                <div class="p-2 bd-highlight">Infrastructures :{props.collegeObj.Infrastructures}</div>
                <div class="p-2 bd-highlight">Intake :{props.collegeObj.Intake}</div>
            </div>
        </div>
    )
}

export default Compcollege;