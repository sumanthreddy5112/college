import React, { useEffect, useState } from 'react';
import './compare.css';
import { collegeData } from '../data.js';
import College from './College';
import Compcollege from './Compcollege';
function Comparison() {
    const [first, setFirst] = useState('');
    const [second, setSecond] = useState('');
    const [val, setVal]= useState({})
    const changeFirst = (event) => {
        setFirst(event.target.value);
    };

    const changeSecond = (event) => {
        setSecond(event.target.value);
    };

    const transferValue = (event) => {
        event.preventDefault();
        setVal({first,second})
        console.log(val);
    }
    return (
        <div>
            <div id='f2'>
                <form className="d-flex w-50" id='cmp' >
                    <div className="col-md-6" id='frcoll'>
                        <input type="text" className="form-control" value={first} onChange={changeFirst} placeholder=' First College' />
                    </div>
                    <div className="col-md-6" id='scoll'>
                        <input type="text" className="form-control" value={second} onChange={changeSecond} placeholder='Second College' />
                    </div>
                    <div className="col-md-6">
                        <button type="submit" onClick={transferValue} className="btn btn-dark">Compare</button>
                    </div>
                </form>
            </div>
            <br></br>
            <div className='d-flex flex-row bd-highlight mb-3 justify-content-evenly' id='cooo'>
                {
                    collegeData.map((collegeObj, index) =>
                        (val.first === collegeObj.Name && <Compcollege key={index} collegeObj={collegeObj}></Compcollege>) || (val.second === collegeObj.Name &&
                        <Compcollege key={index} collegeObj={collegeObj}></Compcollege>))
                }
            </div>

        </div>
    )
}
export default Comparison