import './App.css';
import Home from './components/Home'
import Comparison from './components/Comparison'
import Query from './components/Query'
import {Route,Routes,NavLink,Navigate} from 'react-router-dom';

function App() {
  return (
    <div>
      <nav className="navbar navbar-expand-sm navbar-dark bg-dark">
  <div className="container-fluid">
    <a className="navbar-brand" href="#">Collage Info</a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNavDropdown">
      <ul className="navbar-nav">
        <li className="nav-item">
          <NavLink className="nav-link" to="">Home</NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link" to="comparison">Comparison</NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link" to="query">Ask us</NavLink>
        </li>  
      </ul>
      
    </div>
  </div>
</nav>
<Routes>
  <Route path="" element={<Home/>}></Route>
  <Route path="comparison" element={<Comparison/>}></Route>
  <Route path="query" element={<Query/>}></Route>
</Routes>

    </div>
  );
}

export default App;
